@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Register</div>

                <div class="card-body" align="center">
                    <h4><b>Sorry !!!</b> You don't have access to register user.</h4>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
