


@include('branches.header')
<!-- Page Content -->
@yield('content')

@include('branches.footer')
